# Xerxes
Powerfull DDoS Attack tool Created in Python By Mr. Thg
